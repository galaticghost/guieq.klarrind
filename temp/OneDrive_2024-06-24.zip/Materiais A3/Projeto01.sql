-- -----------------------------------------------------
-- Schema gestaodespesas
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `gestaodespesas` DEFAULT CHARACTER SET utf8 ;
USE `gestaodespesas` ;

-- -----------------------------------------------------
-- Table `gestaodespesas`.`perfil`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`perfil` (
  `idPerfil` INT NOT NULL AUTO_INCREMENT,
  `nomePerfil` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NULL,
  `ativo` ENUM('S', 'N') NULL,
  PRIMARY KEY (`idPerfil`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaodespesas`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`usuario` (
  `idUsuario` INT NOT NULL AUTO_INCREMENT,
  `idPerfil` INT NOT NULL,
  `nomeUsuario` VARCHAR(255) NOT NULL,	
  `emailUsuario` VARCHAR(255) NOT NULL,
  `loginUsuario` VARCHAR(255) NOT NULL,
  `senhaUsuario` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NULL,
  `telefoneCelular` VARCHAR(45) NULL,
  `ativo` ENUM('S', 'N') NULL DEFAULT 'S',
  PRIMARY KEY (`idUsuario`, `idPerfil`),
  INDEX `fk_usuario_perfil1_idx` (`idPerfil` ASC) ,
  CONSTRAINT `fk_usuario_perfil1`
    FOREIGN KEY (`idPerfil`)
    REFERENCES `gestaodespesas`.`perfil` (`idPerfil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = INNODB;

-- -----------------------------------------------------
-- Table `gestaodespesas`.`credor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`credor` (
  `idCredor` INT NOT NULL AUTO_INCREMENT,
  `idUsuario` INT NOT NULL,
  `nomeCredor` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NOT NULL,
  `responsavelCredor` VARCHAR(45) NULL,
  `telefoneCredor` VARCHAR(45) NULL,
  `celularCredor` VARCHAR(45) NULL,
  `ativo` ENUM('S', 'N') NULL DEFAULT 'S',
  PRIMARY KEY (`idCredor`, `idUsuario`),
  INDEX `fk_credor_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_credor_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaodespesas`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `gestaodespesas`.`despesa`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`despesa` (
  `idDespesa` INT NOT NULL AUTO_INCREMENT,
  `idCredor` INT NOT NULL,
  `idUsuario` INT NOT NULL,
  `nomeDespesa` VARCHAR(45) NOT NULL,
  `dataCadastro` DATETIME NOT NULL,
  `ativo` ENUM('S', 'N') NULL,
  PRIMARY KEY (`idDespesa`, `idCredor`, `idUsuario`),
  INDEX `fk_despesa_credor_idx` (`idCredor` ASC) ,
  INDEX `fk_despesa_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_despesa_credor`
    FOREIGN KEY (`idCredor`)
    REFERENCES `gestaodespesas`.`credor` (`idCredor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_despesa_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaodespesas`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `gestaodespesas`.`base`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`base` (
  `idBase` INT NOT NULL AUTO_INCREMENT,
  `idUsuario` INT NOT NULL,
  `nomeBase` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NULL,
  `responsavelBase` VARCHAR(45) NULL,
  `telefoneBase` VARCHAR(45) NULL,
  `celularBase` VARCHAR(45) NULL,
  `emailBase` VARCHAR(45) NULL,
  `ativo` ENUM('S', 'N') NULL DEFAULT 'S',
  PRIMARY KEY (`idBase`, `idUsuario`),
  INDEX `fk_base_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_base_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaodespesas`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `gestaodespesas`.`sessao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`sessao` (
  `idSessao` INT NOT NULL AUTO_INCREMENT,
  `nomeSessao` VARCHAR(255) NOT NULL,
  `dataCadsatro` DATETIME NULL,
  PRIMARY KEY (`idSessao`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `gestaodespesas`.`perfilsessao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`perfilsessao` (
  `idPerfil` INT NOT NULL,
  `idSessao` INT NOT NULL,
  PRIMARY KEY (`idPerfil`, `idSessao`),
  INDEX `fk_perfil_has_sessao_sessao1_idx` (`idSessao` ASC) ,
  INDEX `fk_perfil_has_sessao_perfil1_idx` (`idPerfil` ASC) ,
  CONSTRAINT `fk_perfil_has_sessao_perfil1`
    FOREIGN KEY (`idPerfil`)
    REFERENCES `gestaodespesas`.`perfil` (`idPerfil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_perfil_has_sessao_sessao1`
    FOREIGN KEY (`idSessao`)
    REFERENCES `gestaodespesas`.`sessao` (`idSessao`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = INNODB;

-- -----------------------------------------------------
-- Table `gestaodespesas`.`lancamento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaodespesas`.`lancamento` (
  `idLancamento` INT NOT NULL AUTO_INCREMENT,
  `idBase` INT NOT NULL,
  `idUsuario` INT NOT NULL,
  `idDespesa` INT NOT NULL,
  `competenciaDespesa` CHAR(2) NOT NULL,
  `dataVencimento` DATE NOT NULL,
  `valorLiquido` FLOAT(10,2) NOT NULL,
  `valorMulta` FLOAT(10,2) NOT NULL,
  `valorCorrecao` FLOAT(10,2) NOT NULL,
  `dataCadastro` DATETIME NOT NULL,
  `ativo` ENUM('S', 'N') NOT NULL DEFAULT 'S',
  `observacao` TEXT NULL,
  PRIMARY KEY (`idLancamento`, `idBase`, `idUsuario`, `idDespesa`),
  INDEX `fk_lancamento_despesa1_idx` (`idDespesa` ASC) ,
  INDEX `fk_lancamento_base1_idx` (`idBase` ASC) ,
  INDEX `fk_lancamento_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_lancamento_despesa1`
    FOREIGN KEY (`idDespesa`)
    REFERENCES `gestaodespesas`.`despesa` (`idDespesa`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_lancamento_base1`
    FOREIGN KEY (`idBase`)
    REFERENCES `gestaodespesas`.`base` (`idBase`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_lancamento_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaodespesas`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

