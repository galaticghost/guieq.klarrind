-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema gestaoatendimentos
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema gestaoatendimentos
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `gestaoatendimentos` DEFAULT CHARACTER SET utf8 ;
USE `gestaoatendimentos` ;

-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`perfil`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`perfil` (
  `idPerfil` INT NOT NULL AUTO_INCREMENT,
  `nomePerfil` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NULL,
  `ativo` ENUM('S', 'N') NOT NULL DEFAULT 'S',
  PRIMARY KEY (`idPerfil`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`usuario` (
  `idUsuario` INT NOT NULL AUTO_INCREMENT,
  `nomeUsuario` VARCHAR(255) NOT NULL,
  `emailUsuario` VARCHAR(255) NOT NULL,
  `loginUsuario` VARCHAR(255) NOT NULL,
  `senhaUsuario` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NULL,
  `telefoneCelular` VARCHAR(45) NULL,
  `ativo` ENUM('S', 'N') NOT NULL DEFAULT 'S',
  `idPerfil` INT NOT NULL,
  PRIMARY KEY (`idUsuario`, `idPerfil`),
  INDEX `fk_usuario_perfil1_idx` (`idPerfil` ASC) ,
  CONSTRAINT `fk_usuario_perfil1`
    FOREIGN KEY (`idPerfil`)
    REFERENCES `gestaoatendimentos`.`perfil` (`idPerfil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`sessao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`sessao` (
  `idSessao` INT NOT NULL AUTO_INCREMENT,
  `nomeSessao` VARCHAR(255) NOT NULL,
  `dataCadsatro` DATETIME NULL,
  PRIMARY KEY (`idSessao`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`perfilsessao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`perfilsessao` (
  `idPerfil` INT NOT NULL,
  `idSessao` INT NOT NULL,
  PRIMARY KEY (`idPerfil`, `idSessao`),
  INDEX `fk_perfil_has_sessao_sessao1_idx` (`idSessao` ASC) ,
  INDEX `fk_perfil_has_sessao_perfil1_idx` (`idPerfil` ASC) ,
  CONSTRAINT `fk_perfil_has_sessao_perfil1`
    FOREIGN KEY (`idPerfil`)
    REFERENCES `gestaoatendimentos`.`perfil` (`idPerfil`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_perfil_has_sessao_sessao1`
    FOREIGN KEY (`idSessao`)
    REFERENCES `gestaoatendimentos`.`sessao` (`idSessao`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`formaatendimento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`formaatendimento` (
  `idFormaAtendimento` INT NOT NULL AUTO_INCREMENT,
  `idUsuario` INT NOT NULL,
  `nomeAtendimento` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NOT NULL,
  `ativo` ENUM('S', 'N') NOT NULL DEFAULT 'S',
  PRIMARY KEY (`idFormaAtendimento`, `idUsuario`),
  INDEX `fk_tipoatendimento_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_tipoatendimento_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaoatendimentos`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`publico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`publico` (
  `idPublico` INT NOT NULL AUTO_INCREMENT,
  `idUsuario` INT NOT NULL,
  `nomePublico` VARCHAR(255) NOT NULL,
  `dataCadastro` DATETIME NOT NULL,
  `ativo` ENUM('S', 'N') NOT NULL DEFAULT 'S',
  PRIMARY KEY (`idPublico`, `idUsuario`),
  INDEX `fk_publico_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_publico_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaoatendimentos`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`perguntapublico`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`perguntapublico` (
  `idPerguntaPublico` INT NOT NULL AUTO_INCREMENT,
  `idPublico` INT NOT NULL,
  `idUsuario` INT NOT NULL,
  `descricaoPergunta` TEXT NOT NULL,
  `dataCadastro` DATETIME NOT NULL,
  `ativo` ENUM('S', 'N') NOT NULL DEFAULT 'S',
  PRIMARY KEY (`idPerguntaPublico`, `idPublico`, `idUsuario`),
  INDEX `fk_perguntapublico_publico1_idx` (`idPublico` ASC) ,
  INDEX `fk_perguntapublico_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_perguntapublico_publico1`
    FOREIGN KEY (`idPublico`)
    REFERENCES `gestaoatendimentos`.`publico` (`idPublico`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_perguntapublico_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaoatendimentos`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `gestaoatendimentos`.`atendimento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gestaoatendimentos`.`atendimento` (
  `idAtendimento` INT NOT NULL AUTO_INCREMENT,
  `idFormaAtendimento` INT NOT NULL,
  `idPerguntaPublico` INT NOT NULL,
  `idUsuario` INT NOT NULL,
  `dataCadastro` DATETIME NOT NULL,
  `ativo('S','N')` ENUM('S', 'N') NOT NULL DEFAULT 'S',
  `respostaAtendimento` TEXT NOT NULL,
  PRIMARY KEY (`idAtendimento`, `idFormaAtendimento`, `idPerguntaPublico`, `idUsuario`),
  INDEX `fk_atendimento_formaatendimento1_idx` (`idFormaAtendimento` ASC) ,
  INDEX `fk_atendimento_perguntapublico1_idx` (`idPerguntaPublico` ASC) ,
  INDEX `fk_atendimento_usuario1_idx` (`idUsuario` ASC) ,
  CONSTRAINT `fk_atendimento_formaatendimento1`
    FOREIGN KEY (`idFormaAtendimento`)
    REFERENCES `gestaoatendimentos`.`formaatendimento` (`idFormaAtendimento`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_atendimento_perguntapublico1`
    FOREIGN KEY (`idPerguntaPublico`)
    REFERENCES `gestaoatendimentos`.`perguntapublico` (`idPerguntaPublico`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_atendimento_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `gestaoatendimentos`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
